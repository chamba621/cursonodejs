import { Component, OnInit } from '@angular/core'

@Component({
	selector: 'tienda',
	templateUrl: './tienda.component.html',
	styleUrls: ['./tienda.component.css']
})

export class TiendaComponent implements OnInit{
	public titulo;
	public nombreDelParque: string;
	public miParque;

	constructor(){
		this.titulo = 'Mi tiendita'
	}

	mostrarNombre(){
		console.log(this.nombreDelParque);
	}

	ngOnInit(){
		$('#textoJQ').hide();
		$('#btnJQ').click(function(){
			$('#textoJQ').slideToggle();
		});

		$('#caja').dotdotdot();
	}

	verDatosParque(event)
	{
		console.log(event);
		this.miParque = event;
	}
}