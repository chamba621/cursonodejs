import { Component, DoCheck, OnInit } from '@angular/core';

@Component({
  selector: 'mostrar-email',
  template: `
     <h2>{{title}}</h2>
     <span *ngIf="emailContacto">
        Email de contacto: <strong>{{emailContacto}}</strong>
        <button (click)="eliminarEmailContacto()">Eliminar email de contacto</button>
     </span>
        
  `
})
export class MostrarEmailComponent implements DoCheck, OnInit {
  title = 'Mostrar Email';
  public emailContacto: string;

  ngDoCheck()
  {
  	this.emailContacto = localStorage.getItem('emailContacto');
  }

  ngOnInit()
  {
  	this.emailContacto = localStorage.getItem('emailContacto');
  }

	eliminarEmailContacto(){
		localStorage.removeItem('emailContacto');
		// localStorage.clear();
		this.emailContacto = null;
	}

}
