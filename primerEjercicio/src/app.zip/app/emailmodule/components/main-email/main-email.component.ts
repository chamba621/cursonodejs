import { Component, DoCheck, OnInit } from '@angular/core';

@Component({
  selector: 'main-email',
  template: `
     <h1>{{title}}</h1>
     <guardar-email></guardar-email>
     <mostrar-email></mostrar-email>
  `
})
export class MainEmailComponent{
  title = 'Modulo email';
}
